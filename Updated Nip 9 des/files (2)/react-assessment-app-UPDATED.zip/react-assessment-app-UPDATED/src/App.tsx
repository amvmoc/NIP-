import React, { useState } from 'react';
import { AssessmentProvider } from './context/AssessmentContext';
import { WelcomeScreen } from './components/WelcomeScreen';
import { QuestionScreen } from './components/QuestionScreen';
import { ProgressBar } from './components/ProgressBar';
import { ResultsScreen } from './components/ResultsScreen';
import { AdminPanel } from './components/AdminPanel';
import './App.css';

type AppScreen = 'welcome' | 'assessment' | 'results' | 'admin';

function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('welcome');
  const [showAdmin, setShowAdmin] = useState(false);

  const handleStart = () => {
    setCurrentScreen('assessment');
  };

  const handleComplete = () => {
    setCurrentScreen('results');
  };

  const handleRestart = () => {
    setCurrentScreen('welcome');
  };

  const toggleAdmin = () => {
    setShowAdmin(!showAdmin);
  };

  return (
    <AssessmentProvider>
      <div className="app">
        <header className="app-header">
          <div className="container">
            <h1>Neural Imprint Patterns Assessment</h1>
            <p className="tagline">Discover Your Unconscious Patterns</p>
          </div>
        </header>

        <main className="app-main">
          <div className="container">
            {currentScreen === 'assessment' && <ProgressBar />}

            {currentScreen === 'welcome' && (
              <WelcomeScreen onStart={handleStart} />
            )}

            {currentScreen === 'assessment' && (
              <QuestionScreen onComplete={handleComplete} />
            )}

            {currentScreen === 'results' && (
              <ResultsScreen onRestart={handleRestart} />
            )}

            {showAdmin && (
              <AdminPanel onClose={toggleAdmin} />
            )}
          </div>
        </main>

        <footer className="app-footer">
          <div className="container">
            <p>&copy; 2025 Neural Imprint Patterns Assessment. All rights reserved.</p>
            <button 
              onClick={toggleAdmin}
              className="admin-toggle"
              style={{ opacity: 0.1 }}
            >
              Admin
            </button>
          </div>
        </footer>
      </div>
    </AssessmentProvider>
  );
}

export default App;
